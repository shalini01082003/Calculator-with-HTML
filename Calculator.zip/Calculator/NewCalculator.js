// CALCULATOR PROGRAM

const display = document.getElementById("display");

function appendToDisplay(input){
    display.value += input;

}

function clearDisplay(){
    display.value = "";

}

function calculate(){
    try{
        display.value = math.evaluate(display.value);
      
    }
    catch(error){
        display.value = "Error";  
    }
    // let x = document.getElementById("display").value 
    // let y = math.evaluate(x) 
    // document.getElementById("display").value = y 
    
    

}